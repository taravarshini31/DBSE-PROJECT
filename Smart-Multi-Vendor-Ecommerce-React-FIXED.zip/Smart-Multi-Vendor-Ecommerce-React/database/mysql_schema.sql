-- Optional DBSE schema reference for Vendly
CREATE DATABASE IF NOT EXISTS vendly_marketplace;
USE vendly_marketplace;
CREATE TABLE users (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(120), email VARCHAR(160) UNIQUE, password_hash VARCHAR(255), role ENUM('customer','vendor','admin') DEFAULT 'customer', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE vendors (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(150), rating DECIMAL(2,1), trust_score INT, delivery_days VARCHAR(30), return_rate DECIMAL(5,2));
CREATE TABLE products (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(180), category VARCHAR(80), price DECIMAL(12,2), mrp DECIMAL(12,2), vendor_id INT, stock_qty INT, low_stock_threshold INT, FOREIGN KEY (vendor_id) REFERENCES vendors(id));
CREATE TABLE orders (id INT PRIMARY KEY AUTO_INCREMENT, order_code VARCHAR(30) UNIQUE, user_id INT, total_amount DECIMAL(12,2), payment_method VARCHAR(30), payment_status VARCHAR(30), order_status VARCHAR(40), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (user_id) REFERENCES users(id));
CREATE TABLE order_items (id INT PRIMARY KEY AUTO_INCREMENT, order_id INT, product_id INT, quantity INT, unit_price DECIMAL(12,2), FOREIGN KEY (order_id) REFERENCES orders(id), FOREIGN KEY (product_id) REFERENCES products(id));
CREATE TABLE payments (id INT PRIMARY KEY AUTO_INCREMENT, order_id INT, method VARCHAR(30), transaction_ref VARCHAR(80), amount DECIMAL(12,2), status VARCHAR(30), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (order_id) REFERENCES orders(id));
CREATE TABLE inventory_alerts (id INT PRIMARY KEY AUTO_INCREMENT, product_id INT, alert_type VARCHAR(30), message VARCHAR(255), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (product_id) REFERENCES products(id));
