# MongoDB collections (reference)

Suggested collections from the project abstract:
- customer_activity
- search_history
- product_views
- reviews
- recommendations
- notifications
- analytics

The React demo uses LocalStorage so it can run without a database. These collections can be connected later through an Express API.
