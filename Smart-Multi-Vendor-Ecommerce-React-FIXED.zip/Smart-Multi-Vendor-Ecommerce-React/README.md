# Vendly — Smart Multi-Vendor E-Commerce Marketplace (React.js)

A polished React + Vite college-project demo covering the seven requirements:

1. Multiple vendors
2. Product management
3. Customers/users
4. Orders
5. Payments (demo checkout: UPI, Card, Net Banking, COD)
6. Inventory management + low-stock alerts
7. Order tracking

## Extra features
- Vendor trust score and seller comparison
- Multi-vendor cart
- Product search, category filters and sorting
- Wishlist
- Price-history chart
- Smart recommendations / curated products
- Vendor Seller Hub with add-product and stock update
- Admin Console
- Responsive design
- LocalStorage persistence so data survives refresh

## Run in VS Code
1. Extract the ZIP.
2. Open the extracted folder in VS Code.
3. Open Terminal.
4. Run:

```bash
npm install
npm run dev
```

5. Open the URL shown by Vite, normally `http://localhost:5173/`.

## Important
This version is designed to run immediately as a frontend demonstration. Payment is simulated and does not charge real money. Product, cart, wishlist and order changes are stored in the browser's LocalStorage.

For a DBSE submission, the project can later be connected to MySQL/MongoDB and a real payment gateway without changing the UI structure.
