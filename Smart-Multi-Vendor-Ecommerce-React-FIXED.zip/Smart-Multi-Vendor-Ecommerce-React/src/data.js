export const vendors = [
  {id:'v1',name:'TechNova Store',category:'Electronics',rating:4.8,trust:96,delivery:'1–2 days',returns:'2.1%',orders:1842,badge:'Top Rated',color:'#eef2ff'},
  {id:'v2',name:'Urban Cart',category:'Lifestyle',rating:4.6,trust:91,delivery:'2–3 days',returns:'3.4%',orders:1268,badge:'Fast Delivery',color:'#ecfeff'},
  {id:'v3',name:'HomeNest',category:'Home & Living',rating:4.7,trust:94,delivery:'2–4 days',returns:'2.8%',orders:934,badge:'Trusted Seller',color:'#f0fdf4'},
  {id:'v4',name:'StyleStreet',category:'Fashion',rating:4.5,trust:88,delivery:'3–5 days',returns:'4.2%',orders:1107,badge:'Popular',color:'#fff7ed'}
];
export const products = [
  {id:1,name:'Nova X Pro Smartphone',category:'Electronics',price:38999,mrp:44999,rating:4.8,reviews:284,image:'📱',vendorId:'v1',stock:24,threshold:8,tag:'Best Seller',desc:'AMOLED display, 5G, 256GB storage and all-day battery.',history:[42000,40999,39999,38999]},
  {id:2,name:'AirBeat Pro Headphones',category:'Electronics',price:4999,mrp:6999,rating:4.6,reviews:173,image:'🎧',vendorId:'v1',stock:41,threshold:10,tag:'Deal',desc:'Wireless ANC headphones with 40-hour battery life.',history:[5999,5799,5299,4999]},
  {id:3,name:'Everyday Canvas Sneakers',category:'Fashion',price:2299,mrp:3299,rating:4.5,reviews:96,image:'👟',vendorId:'v4',stock:7,threshold:10,tag:'Low Stock',desc:'Lightweight everyday sneakers with cushioned sole.',history:[2499,2399,2299,2299]},
  {id:4,name:'Minimal Desk Lamp',category:'Home & Living',price:1499,mrp:1999,rating:4.7,reviews:71,image:'💡',vendorId:'v3',stock:32,threshold:8,tag:'Trending',desc:'Adjustable warm/cool LED desk lamp for study and work.',history:[1799,1699,1599,1499]},
  {id:5,name:'Smart Fitness Watch',category:'Electronics',price:2999,mrp:4999,rating:4.4,reviews:128,image:'⌚',vendorId:'v2',stock:18,threshold:6,tag:'Hot Pick',desc:'Health tracking, notifications, sports modes and sleep insights.',history:[3999,3499,3199,2999]},
  {id:6,name:'CloudSoft Hoodie',category:'Fashion',price:1799,mrp:2499,rating:4.6,reviews:62,image:'🧥',vendorId:'v4',stock:15,threshold:5,tag:'New',desc:'Soft fleece hoodie with relaxed fit and premium finish.',history:[2199,1999,1899,1799]},
  {id:7,name:'BrewMate Coffee Maker',category:'Home & Living',price:3499,mrp:4499,rating:4.7,reviews:88,image:'☕',vendorId:'v3',stock:4,threshold:7,tag:'Low Stock',desc:'Compact coffee maker with reusable filter and timer.',history:[3999,3799,3599,3499]},
  {id:8,name:'PowerCore 20K Power Bank',category:'Electronics',price:1799,mrp:2499,rating:4.5,reviews:211,image:'🔋',vendorId:'v1',stock:56,threshold:12,tag:'Best Seller',desc:'20,000mAh fast-charging power bank with dual USB output.',history:[2299,2099,1899,1799]},
  {id:9,name:'Luxe Everyday Backpack',category:'Lifestyle',price:1899,mrp:2799,rating:4.5,reviews:54,image:'🎒',vendorId:'v2',stock:21,threshold:6,tag:'Popular',desc:'Water-resistant backpack with laptop compartment.',history:[2499,2299,1999,1899]},
  {id:10,name:'Glow Skin Care Set',category:'Lifestyle',price:1299,mrp:1699,rating:4.3,reviews:102,image:'🧴',vendorId:'v2',stock:13,threshold:5,tag:'Value Pack',desc:'Daily essentials set with cleanser, moisturizer and serum.',history:[1599,1499,1399,1299]}
];
export const categories=['All','Electronics','Fashion','Home & Living','Lifestyle'];
export const initialOrders=[
 {id:'VND-1048',date:'02 Oct 2026',items:[{productId:1,qty:1},{productId:2,qty:1}],total:43998,status:'Shipped',payment:'UPI',vendor:'TechNova Store',eta:'04 Oct 2026'},
 {id:'VND-1039',date:'28 Sep 2026',items:[{productId:4,qty:2}],total:2998,status:'Delivered',payment:'Card',vendor:'HomeNest',eta:'Delivered'},
];
