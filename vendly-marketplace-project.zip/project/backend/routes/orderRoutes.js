const express = require('express');
const router = express.Router();
const { checkout, getMyOrders } = require('../controllers/orderController');
const { authenticate } = require('../middleware/auth');

router.use(authenticate);
router.post('/checkout', checkout);
router.get('/', getMyOrders);

module.exports = router;
