const express = require('express');
const router = express.Router();
const { getRecommendations } = require('../controllers/recommendationController');
const { authenticate } = require('../middleware/auth');

router.use(authenticate);
router.get('/', getRecommendations);

module.exports = router;
