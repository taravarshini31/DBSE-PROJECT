const express = require('express');
const router = express.Router();
const { getDashboard, recomputeTrustScore, updateListing } = require('../controllers/vendorController');
const { authenticate, requireRole } = require('../middleware/auth');

router.use(authenticate, requireRole('vendor'));
router.get('/me/dashboard', getDashboard);
router.put('/me/trust-score/recompute', recomputeTrustScore);
router.put('/me/listings/:listingId', updateListing);

module.exports = router;
