const express = require('express');
const router = express.Router();
const { getAllProducts, getProductDetail, getPriceHistory } = require('../controllers/productController');
const { authenticate } = require('../middleware/auth');

router.get('/', getAllProducts);
router.get('/:id', authenticate, getProductDetail);
router.get('/:id/price-history', getPriceHistory);

module.exports = router;
