const express = require('express');
const router = express.Router();
const { addItem, getCart, removeItem } = require('../controllers/cartController');
const { authenticate } = require('../middleware/auth');

router.use(authenticate);
router.get('/', getCart);
router.post('/items', addItem);
router.delete('/items/:cartItemId', removeItem);

module.exports = router;
