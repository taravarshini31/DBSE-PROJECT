const pool = require('../config/mysqlDb');

async function getOrCreateCart(userId) {
  const [rows] = await pool.query('SELECT cart_id FROM cart WHERE user_id = ?', [userId]);
  if (rows.length) return rows[0].cart_id;
  const [result] = await pool.query('INSERT INTO cart (user_id) VALUES (?)', [userId]);
  return result.insertId;
}

// POST /api/cart/items { listing_id, quantity }
exports.addItem = async (req, res) => {
  try {
    const { listing_id, quantity = 1 } = req.body;
    const cartId = await getOrCreateCart(req.user.user_id);

    const [existing] = await pool.query(
      'SELECT cart_item_id, quantity FROM cart_items WHERE cart_id = ? AND listing_id = ?',
      [cartId, listing_id]
    );
    if (existing.length) {
      await pool.query('UPDATE cart_items SET quantity = quantity + ? WHERE cart_item_id = ?', [
        quantity,
        existing[0].cart_item_id
      ]);
    } else {
      await pool.query('INSERT INTO cart_items (cart_id, listing_id, quantity) VALUES (?,?,?)', [
        cartId,
        listing_id,
        quantity
      ]);
    }
    res.status(201).json({ message: 'Item added to cart' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET /api/cart - returns items GROUPED BY VENDOR (the "Multi-Vendor Cart" feature)
exports.getCart = async (req, res) => {
  try {
    const cartId = await getOrCreateCart(req.user.user_id);

    const [items] = await pool.query(
      `SELECT ci.cart_item_id, ci.quantity, vl.listing_id, vl.price, vl.stock_qty,
              p.product_id, p.name, p.image_url,
              v.vendor_id, v.store_name, v.trust_score
       FROM cart_items ci
       JOIN vendor_listings vl ON ci.listing_id = vl.listing_id
       JOIN products p ON vl.product_id = p.product_id
       JOIN vendors v ON vl.vendor_id = v.vendor_id
       WHERE ci.cart_id = ?`,
      [cartId]
    );

    const grouped = {};
    let grandTotal = 0;
    for (const item of items) {
      const key = item.vendor_id;
      if (!grouped[key]) {
        grouped[key] = {
          vendor_id: item.vendor_id,
          store_name: item.store_name,
          trust_score: item.trust_score,
          items: [],
          subtotal: 0
        };
      }
      const lineTotal = Number(item.price) * item.quantity;
      grouped[key].items.push({ ...item, lineTotal });
      grouped[key].subtotal += lineTotal;
      grandTotal += lineTotal;
    }

    res.json({ vendors: Object.values(grouped), grandTotal });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// DELETE /api/cart/items/:cartItemId
exports.removeItem = async (req, res) => {
  try {
    await pool.query('DELETE FROM cart_items WHERE cart_item_id = ?', [req.params.cartItemId]);
    res.json({ message: 'Item removed' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
