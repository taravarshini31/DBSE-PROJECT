const pool = require('../config/mysqlDb');
const { ProductView } = require('../models/mongoModels');
const { buildCategoryAffinity, getTrending } = require('../utils/recommendation');

// GET /api/recommendations - personalized "Product Recommendations" feature
exports.getRecommendations = async (req, res) => {
  try {
    const userId = req.user.user_id;
    const affinity = await buildCategoryAffinity(pool, ProductView, userId);

    let recommended = [];
    if (affinity.length) {
      const categoryIds = affinity.map((a) => a.category_id);
      const [rows] = await pool.query(
        `SELECT p.product_id, p.name, p.image_url, MIN(vl.price) as min_price
         FROM products p JOIN vendor_listings vl ON p.product_id = vl.product_id
         WHERE p.category_id IN (?) AND vl.is_active = 1
         GROUP BY p.product_id LIMIT 10`,
        [categoryIds]
      );
      recommended = rows.map((r) => ({ ...r, reason: 'Based on categories you browse often' }));
    }

    if (recommended.length < 5) {
      // cold-start fallback: trending items
      const trending = await getTrending(ProductView, 7, 10);
      const trendingIds = trending.map((t) => t._id).filter(Boolean);
      if (trendingIds.length) {
        const [rows] = await pool.query(
          `SELECT p.product_id, p.name, p.image_url, MIN(vl.price) as min_price
           FROM products p JOIN vendor_listings vl ON p.product_id = vl.product_id
           WHERE p.product_id IN (?) AND vl.is_active = 1
           GROUP BY p.product_id`,
          [trendingIds]
        );
        rows.forEach((r) => recommended.push({ ...r, reason: 'Trending this week' }));
      }
    }

    res.json({ recommendations: recommended.slice(0, 10) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
