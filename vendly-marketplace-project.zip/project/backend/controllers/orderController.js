const pool = require('../config/mysqlDb');
const crypto = require('crypto');

// POST /api/orders/checkout - converts the multi-vendor cart into
// ONE order with a sub-order (order_vendor_split) per vendor
exports.checkout = async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const userId = req.user.user_id;

    const [cartRows] = await conn.query('SELECT cart_id FROM cart WHERE user_id = ?', [userId]);
    if (!cartRows.length) throw new Error('Cart is empty');
    const cartId = cartRows[0].cart_id;

    const [items] = await conn.query(
      `SELECT ci.cart_item_id, ci.quantity, vl.listing_id, vl.price, vl.stock_qty, vl.vendor_id
       FROM cart_items ci JOIN vendor_listings vl ON ci.listing_id = vl.listing_id
       WHERE ci.cart_id = ? FOR UPDATE`,
      [cartId]
    );
    if (!items.length) throw new Error('Cart is empty');

    // stock check
    for (const item of items) {
      if (item.quantity > item.stock_qty) {
        throw new Error(`Insufficient stock for listing ${item.listing_id}`);
      }
    }

    const totalAmount = items.reduce((sum, i) => sum + Number(i.price) * i.quantity, 0);
    const orderGroupId = crypto.randomUUID();

    const [orderResult] = await conn.query(
      'INSERT INTO orders (user_id, order_group_id, total_amount) VALUES (?,?,?)',
      [userId, orderGroupId, totalAmount]
    );
    const orderId = orderResult.insertId;

    // group by vendor -> create sub-orders
    const byVendor = {};
    for (const item of items) {
      if (!byVendor[item.vendor_id]) byVendor[item.vendor_id] = [];
      byVendor[item.vendor_id].push(item);
    }

    for (const vendorId of Object.keys(byVendor)) {
      const vendorItems = byVendor[vendorId];
      const subTotal = vendorItems.reduce((s, i) => s + Number(i.price) * i.quantity, 0);

      await conn.query(
        'INSERT INTO order_vendor_split (order_id, vendor_id, sub_total) VALUES (?,?,?)',
        [orderId, vendorId, subTotal]
      );

      for (const item of vendorItems) {
        await conn.query(
          `INSERT INTO order_items (order_id, listing_id, vendor_id, quantity, price_at_purchase)
           VALUES (?,?,?,?,?)`,
          [orderId, item.listing_id, vendorId, item.quantity, item.price]
        );
        // decrement stock -> may trigger a low-stock alert (see inventoryController)
        await conn.query('UPDATE vendor_listings SET stock_qty = stock_qty - ? WHERE listing_id = ?', [
          item.quantity,
          item.listing_id
        ]);
      }
    }

    await conn.query('DELETE FROM cart_items WHERE cart_id = ?', [cartId]);
    await conn.commit();

    res.status(201).json({ order_id: orderId, order_group_id: orderGroupId, total_amount: totalAmount });
  } catch (err) {
    await conn.rollback();
    res.status(400).json({ error: err.message });
  } finally {
    conn.release();
  }
};

// GET /api/orders - order history for logged in user
exports.getMyOrders = async (req, res) => {
  try {
    const [orders] = await pool.query(
      'SELECT * FROM orders WHERE user_id = ? ORDER BY placed_at DESC',
      [req.user.user_id]
    );
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
