const pool = require('../config/mysqlDb');
const { computeTrustScore } = require('../utils/trustScore');
const { Notification } = require('../models/mongoModels');

// GET /api/vendors/me/dashboard
exports.getDashboard = async (req, res) => {
  try {
    const [[vendor]] = await pool.query(
      'SELECT * FROM vendors WHERE user_id = ?',
      [req.user.user_id]
    );
    if (!vendor) return res.status(404).json({ error: 'Vendor profile not found' });

    const [[salesRow]] = await pool.query(
      `SELECT COUNT(DISTINCT ovs.split_id) as total_orders, COALESCE(SUM(ovs.sub_total),0) as total_revenue
       FROM order_vendor_split ovs WHERE ovs.vendor_id = ?`,
      [vendor.vendor_id]
    );

    const [listings] = await pool.query(
      'SELECT * FROM vendor_listings WHERE vendor_id = ?',
      [vendor.vendor_id]
    );

    const [alerts] = await pool.query(
      `SELECT * FROM inventory_alerts WHERE vendor_id = ? AND is_resolved = 0 ORDER BY created_at DESC`,
      [vendor.vendor_id]
    );

    res.json({ vendor, sales: salesRow, listings, alerts });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// PUT /api/vendors/me/trust-score/recompute
// Recalculates trust score from live stats (demonstrate this live in your review!)
exports.recomputeTrustScore = async (req, res) => {
  try {
    const [[vendor]] = await pool.query('SELECT * FROM vendors WHERE user_id = ?', [req.user.user_id]);
    if (!vendor) return res.status(404).json({ error: 'Vendor not found' });

    const [[ratingRow]] = await pool.query(
      `SELECT COALESCE(AVG(r.rating),0) as avg_rating
       FROM reviews r JOIN vendor_listings vl ON r.listing_id = vl.listing_id
       WHERE vl.vendor_id = ?`,
      [vendor.vendor_id]
    );

    const newScore = computeTrustScore({
      onTimeRate: vendor.on_time_rate,
      completionRate: vendor.order_completion_rate,
      returnRate: vendor.return_rate,
      avgRating: ratingRow.avg_rating,
      avgDeliveryDays: vendor.avg_delivery_days
    });

    await pool.query('UPDATE vendors SET trust_score = ? WHERE vendor_id = ?', [
      newScore,
      vendor.vendor_id
    ]);

    res.json({ vendor_id: vendor.vendor_id, new_trust_score: newScore });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// PUT /api/vendors/me/listings/:listingId  { price?, stock_qty? }
exports.updateListing = async (req, res) => {
  try {
    const { listingId } = req.params;
    const { price, stock_qty } = req.body;

    const [[listing]] = await pool.query('SELECT * FROM vendor_listings WHERE listing_id = ?', [
      listingId
    ]);
    if (!listing) return res.status(404).json({ error: 'Listing not found' });

    if (price !== undefined) {
      await pool.query('UPDATE vendor_listings SET price = ? WHERE listing_id = ?', [price, listingId]);
      await pool.query('INSERT INTO price_history (listing_id, price) VALUES (?, ?)', [listingId, price]);
    }
    if (stock_qty !== undefined) {
      await pool.query('UPDATE vendor_listings SET stock_qty = ? WHERE listing_id = ?', [
        stock_qty,
        listingId
      ]);
      await maybeCreateStockAlert(listingId, listing.vendor_id, stock_qty, listing.low_stock_threshold);
    }

    res.json({ message: 'Listing updated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// SMART INVENTORY ALERTS - triggered whenever stock changes
async function maybeCreateStockAlert(listingId, vendorId, newStock, threshold) {
  let alertType = null;
  let message = null;

  if (newStock <= 0) {
    alertType = 'out_of_stock';
    message = `Listing #${listingId} is now OUT OF STOCK`;
  } else if (newStock <= threshold) {
    alertType = 'low_stock';
    message = `Listing #${listingId} is low on stock (${newStock} left)`;
  }

  if (alertType) {
    await pool.query(
      'INSERT INTO inventory_alerts (listing_id, vendor_id, alert_type, message) VALUES (?,?,?,?)',
      [listingId, vendorId, alertType, message]
    );
    Notification.create({
      recipient_id: vendorId,
      recipient_type: 'vendor',
      type: alertType === 'out_of_stock' ? 'low_stock' : 'low_stock',
      message
    }).catch(() => {});
  }
}

module.exports.maybeCreateStockAlert = maybeCreateStockAlert;
