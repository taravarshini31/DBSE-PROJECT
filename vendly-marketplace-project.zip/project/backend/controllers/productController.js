const pool = require('../config/mysqlDb');
const { rankVendorListings } = require('../utils/trustScore');
const { ProductView } = require('../models/mongoModels');

// GET /api/products - browse catalog
exports.getAllProducts = async (req, res) => {
  try {
    const { category, search } = req.query;
    let query = `
      SELECT p.product_id, p.name, p.brand, p.image_url, p.category_id,
             MIN(vl.price) as min_price, MAX(vl.price) as max_price,
             COUNT(DISTINCT vl.vendor_id) as vendor_count
      FROM products p
      JOIN vendor_listings vl ON p.product_id = vl.product_id AND vl.is_active = 1
      WHERE 1=1`;
    const params = [];
    if (category) { query += ' AND p.category_id = ?'; params.push(category); }
    if (search) { query += ' AND p.name LIKE ?'; params.push(`%${search}%`); }
    query += ' GROUP BY p.product_id';

    const [rows] = await pool.query(query, params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET /api/products/:id - product detail with ALL vendor offers ranked
// by Smart Vendor Matching (price + trust score blended)
exports.getProductDetail = async (req, res) => {
  try {
    const { id } = req.params;

    const [productRows] = await pool.query('SELECT * FROM products WHERE product_id = ?', [id]);
    if (!productRows.length) return res.status(404).json({ error: 'Product not found' });

    const [listings] = await pool.query(
      `SELECT vl.listing_id, vl.price, vl.stock_qty, vl.condition_type,
              v.vendor_id, v.store_name, v.trust_score, v.avg_delivery_days,
              v.is_verified,
              COALESCE((SELECT AVG(rating) FROM reviews r WHERE r.listing_id = vl.listing_id), 0) as avg_rating
       FROM vendor_listings vl
       JOIN vendors v ON vl.vendor_id = v.vendor_id
       WHERE vl.product_id = ? AND vl.is_active = 1`,
      [id]
    );

    const ranked = rankVendorListings(listings);

    // fire-and-forget view log for recommendation engine
    if (req.user) {
      ProductView.create({
        user_id: req.user.user_id,
        product_id: id,
        listing_id: ranked[0]?.listing_id,
        session_id: req.headers['x-session-id'] || 'anonymous'
      }).catch(() => {});
    }

    res.json({ product: productRows[0], offers: ranked });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET /api/products/:id/price-history?listing_id=
exports.getPriceHistory = async (req, res) => {
  try {
    const { listing_id } = req.query;
    if (!listing_id) return res.status(400).json({ error: 'listing_id is required' });

    const [rows] = await pool.query(
      'SELECT price, recorded_at FROM price_history WHERE listing_id = ? ORDER BY recorded_at ASC',
      [listing_id]
    );

    const prices = rows.map((r) => Number(r.price));
    const lowest = prices.length ? Math.min(...prices) : null;
    const highest = prices.length ? Math.max(...prices) : null;
    const current = prices[prices.length - 1] ?? null;
    const isGoodDeal = current !== null && lowest !== null && current <= lowest * 1.05;

    res.json({ history: rows, insight: { lowest, highest, current, isGoodDeal } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
