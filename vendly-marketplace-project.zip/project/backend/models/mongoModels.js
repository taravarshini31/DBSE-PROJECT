const mongoose = require('mongoose');
const { Schema } = mongoose;

const SearchHistorySchema = new Schema({
  user_id: { type: Number, required: true, index: true },
  query: String,
  filters_applied: Schema.Types.Mixed,
  searched_at: { type: Date, default: Date.now }
});

const ProductViewSchema = new Schema({
  user_id: { type: Number, index: true },
  product_id: { type: Number, index: true },
  listing_id: Number,
  session_id: String,
  viewed_at: { type: Date, default: Date.now }
});

const RecommendationSchema = new Schema({
  user_id: { type: Number, required: true, unique: true, index: true },
  generated_at: { type: Date, default: Date.now },
  items: [
    {
      product_id: Number,
      score: Number,
      reason: String
    }
  ]
});

const ReviewDetailSchema = new Schema({
  review_id: { type: Number, required: true, index: true },
  listing_id: Number,
  title: String,
  body: String,
  images: [String],
  helpful_votes: { type: Number, default: 0 },
  vendor_reply: {
    text: String,
    replied_at: Date
  }
});

const NotificationSchema = new Schema({
  recipient_id: { type: Number, required: true, index: true },
  recipient_type: { type: String, enum: ['customer', 'vendor'] },
  type: { type: String, enum: ['low_stock', 'price_drop', 'order_update', 'demand_spike'] },
  message: String,
  is_read: { type: Boolean, default: false },
  created_at: { type: Date, default: Date.now }
});

const VendorActivityLogSchema = new Schema({
  vendor_id: { type: Number, required: true, index: true },
  action: String,
  details: Schema.Types.Mixed,
  timestamp: { type: Date, default: Date.now }
});

module.exports = {
  SearchHistory: mongoose.model('SearchHistory', SearchHistorySchema),
  ProductView: mongoose.model('ProductView', ProductViewSchema),
  Recommendation: mongoose.model('Recommendation', RecommendationSchema),
  ReviewDetail: mongoose.model('ReviewDetail', ReviewDetailSchema),
  Notification: mongoose.model('Notification', NotificationSchema),
  VendorActivityLog: mongoose.model('VendorActivityLog', VendorActivityLogSchema)
};
