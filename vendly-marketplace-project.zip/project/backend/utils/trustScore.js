/**
 * SMART VENDOR MATCHING ENGINE
 * ------------------------------------------------------------
 * Computes a Vendor Trust Score (0-100) from weighted signals.
 * This is the core "unique" algorithm to demo/explain in your review.
 *
 * Weights (tune these and mention the reasoning in your viva):
 *   - On-time delivery rate   : 30%
 *   - Order completion rate   : 25%
 *   - Return rate (inverted)  : 20%
 *   - Average customer rating : 15%
 *   - Delivery speed (inverted, capped at 7 days) : 10%
 */

function computeTrustScore({
  onTimeRate,        // 0-100
  completionRate,    // 0-100
  returnRate,         // 0-100 (lower is better)
  avgRating,          // 0-5
  avgDeliveryDays     // days (lower is better)
}) {
  const onTimeComponent = onTimeRate * 0.30;
  const completionComponent = completionRate * 0.25;
  const returnComponent = (100 - Math.min(returnRate, 100)) * 0.20;
  const ratingComponent = (avgRating / 5) * 100 * 0.15;
  const speedScore = Math.max(0, 100 - (Math.min(avgDeliveryDays, 7) / 7) * 100);
  const speedComponent = speedScore * 0.10;

  const total =
    onTimeComponent + completionComponent + returnComponent + ratingComponent + speedComponent;

  return Math.round(total * 100) / 100; // 2 decimal places
}

/**
 * SMART VENDOR MATCHING
 * Given multiple vendor listings for the same product, rank them using
 * a blended score of price competitiveness + trust score, not price alone.
 * This is what stops a marketplace from just being "sort by lowest price".
 */
function rankVendorListings(listings) {
  const prices = listings.map((l) => l.price);
  const minPrice = Math.min(...prices);
  const maxPrice = Math.max(...prices);

  return listings
    .map((l) => {
      // price score: cheaper = higher score (1.0 for cheapest, 0 for priciest)
      const priceScore =
        maxPrice === minPrice ? 1 : 1 - (l.price - minPrice) / (maxPrice - minPrice);

      const trustScoreNormalized = l.trust_score / 100;

      // Blended match score: price matters, but trust matters almost as much
      const matchScore = priceScore * 0.55 + trustScoreNormalized * 0.45;

      return { ...l, matchScore: Math.round(matchScore * 1000) / 1000 };
    })
    .sort((a, b) => b.matchScore - a.matchScore);
}

module.exports = { computeTrustScore, rankVendorListings };
