/**
 * PRODUCT RECOMMENDATION ENGINE (rule-based, explainable)
 * ------------------------------------------------------------
 * A lightweight, explainable alternative to a full ML pipeline -
 * ideal for a final-year DB/backend project where the emphasis
 * is on data modeling, not model training.
 *
 * Signals combined:
 *  1. Category affinity from MongoDB search_history / product_views
 *  2. Co-purchase patterns from MySQL order_items (people who bought X also bought Y)
 *  3. Trending items (most viewed in last 7 days) as a cold-start fallback
 */

async function buildCategoryAffinity(mysqlPool, mongoViews, userId) {
  const recentViews = await mongoViews
    .find({ user_id: userId })
    .sort({ viewed_at: -1 })
    .limit(50)
    .lean();

  if (!recentViews.length) return [];

  const productIds = [...new Set(recentViews.map((v) => v.product_id))];
  if (!productIds.length) return [];

  const [rows] = await mysqlPool.query(
    `SELECT category_id, COUNT(*) as freq
     FROM products WHERE product_id IN (?)
     GROUP BY category_id ORDER BY freq DESC`,
    [productIds]
  );
  return rows; // [{category_id, freq}, ...]
}

async function getCoPurchased(mysqlPool, productId) {
  const [rows] = await mysqlPool.query(
    `SELECT oi2.listing_id, p.product_id, p.name, COUNT(*) as together_count
     FROM order_items oi1
     JOIN order_items oi2 ON oi1.order_id = oi2.order_id AND oi1.listing_id != oi2.listing_id
     JOIN vendor_listings vl ON oi2.listing_id = vl.listing_id
     JOIN products p ON vl.product_id = p.product_id
     WHERE oi1.listing_id IN (
        SELECT listing_id FROM vendor_listings WHERE product_id = ?
     )
     GROUP BY oi2.listing_id
     ORDER BY together_count DESC
     LIMIT 5`,
    [productId]
  );
  return rows;
}

async function getTrending(mongoViews, days = 7, limit = 10) {
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  return mongoViews.aggregate([
    { $match: { viewed_at: { $gte: since } } },
    { $group: { _id: '$product_id', views: { $sum: 1 } } },
    { $sort: { views: -1 } },
    { $limit: limit }
  ]);
}

module.exports = { buildCategoryAffinity, getCoPurchased, getTrending };
