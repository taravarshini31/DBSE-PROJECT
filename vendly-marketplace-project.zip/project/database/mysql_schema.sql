-- ============================================================
--  SMART MULTI-VENDOR E-COMMERCE MARKETPLACE
--  MySQL Schema  -  Structured / Transactional Data
--  Engine: InnoDB | Charset: utf8mb4
-- ============================================================

CREATE DATABASE IF NOT EXISTS marketplace_db
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE marketplace_db;

-- ------------------------------------------------------------
-- 1. USERS  (customers, vendors, admins share one identity table)
-- ------------------------------------------------------------
CREATE TABLE users (
  user_id        INT AUTO_INCREMENT PRIMARY KEY,
  name           VARCHAR(120) NOT NULL,
  email          VARCHAR(150) NOT NULL UNIQUE,
  password_hash  VARCHAR(255) NOT NULL,
  phone          VARCHAR(20),
  role           ENUM('customer','vendor','admin') NOT NULL DEFAULT 'customer',
  address_line   VARCHAR(255),
  city           VARCHAR(100),
  state          VARCHAR(100),
  pincode        VARCHAR(10),
  created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  is_active      BOOLEAN DEFAULT TRUE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 2. VENDORS  (extends users with role='vendor')
-- ------------------------------------------------------------
CREATE TABLE vendors (
  vendor_id        INT AUTO_INCREMENT PRIMARY KEY,
  user_id          INT NOT NULL UNIQUE,
  store_name       VARCHAR(150) NOT NULL,
  gst_number       VARCHAR(20),
  store_description TEXT,
  avg_delivery_days DECIMAL(4,1) DEFAULT 3.0,
  return_rate       DECIMAL(5,2) DEFAULT 0.00,      -- % of orders returned
  order_completion_rate DECIMAL(5,2) DEFAULT 100.00,-- % fulfilled successfully
  on_time_rate      DECIMAL(5,2) DEFAULT 100.00,
  trust_score       DECIMAL(5,2) DEFAULT 50.00,     -- computed, see utils/trustScore.js
  is_verified       BOOLEAN DEFAULT FALSE,
  created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 3. CATEGORIES
-- ------------------------------------------------------------
CREATE TABLE categories (
  category_id    INT AUTO_INCREMENT PRIMARY KEY,
  name           VARCHAR(100) NOT NULL UNIQUE,
  parent_id      INT NULL,
  FOREIGN KEY (parent_id) REFERENCES categories(category_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 4. PRODUCTS (master/catalog product - the "listing concept")
-- ------------------------------------------------------------
CREATE TABLE products (
  product_id     INT AUTO_INCREMENT PRIMARY KEY,
  category_id    INT NOT NULL,
  name           VARCHAR(200) NOT NULL,
  description    TEXT,
  brand          VARCHAR(100),
  image_url      VARCHAR(255),
  created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(category_id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 5. VENDOR_LISTINGS  (many vendors can sell the SAME product ->
--    this is what powers "Smart Vendor Matching")
-- ------------------------------------------------------------
CREATE TABLE vendor_listings (
  listing_id     INT AUTO_INCREMENT PRIMARY KEY,
  product_id     INT NOT NULL,
  vendor_id      INT NOT NULL,
  price          DECIMAL(10,2) NOT NULL,
  stock_qty      INT NOT NULL DEFAULT 0,
  low_stock_threshold INT NOT NULL DEFAULT 5,
  condition_type ENUM('new','refurbished') DEFAULT 'new',
  is_active      BOOLEAN DEFAULT TRUE,
  updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_vendor_product (product_id, vendor_id),
  FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
  FOREIGN KEY (vendor_id) REFERENCES vendors(vendor_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 6. PRICE_HISTORY  (per listing, time series -> "Price History Analysis")
-- ------------------------------------------------------------
CREATE TABLE price_history (
  history_id     BIGINT AUTO_INCREMENT PRIMARY KEY,
  listing_id     INT NOT NULL,
  price          DECIMAL(10,2) NOT NULL,
  recorded_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (listing_id) REFERENCES vendor_listings(listing_id) ON DELETE CASCADE,
  INDEX idx_listing_time (listing_id, recorded_at)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 7. CART  &  CART_ITEMS  (Multi-Vendor Cart: one cart, items grouped
--    by vendor at query time using vendor_id on the listing)
-- ------------------------------------------------------------
CREATE TABLE cart (
  cart_id        INT AUTO_INCREMENT PRIMARY KEY,
  user_id        INT NOT NULL UNIQUE,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE cart_items (
  cart_item_id   INT AUTO_INCREMENT PRIMARY KEY,
  cart_id        INT NOT NULL,
  listing_id     INT NOT NULL,
  quantity       INT NOT NULL DEFAULT 1,
  added_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (cart_id) REFERENCES cart(cart_id) ON DELETE CASCADE,
  FOREIGN KEY (listing_id) REFERENCES vendor_listings(listing_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 8. ORDERS  (one checkout can spawn multiple SUB-orders, one per vendor)
-- ------------------------------------------------------------
CREATE TABLE orders (
  order_id       INT AUTO_INCREMENT PRIMARY KEY,
  user_id        INT NOT NULL,
  order_group_id VARCHAR(40) NOT NULL,   -- ties multiple vendor sub-orders from one checkout
  total_amount   DECIMAL(10,2) NOT NULL,
  order_status   ENUM('pending','confirmed','shipped','delivered','cancelled','returned')
                 DEFAULT 'pending',
  payment_status ENUM('pending','paid','failed','refunded') DEFAULT 'pending',
  placed_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id)
) ENGINE=InnoDB;

CREATE TABLE order_vendor_split (
  split_id       INT AUTO_INCREMENT PRIMARY KEY,
  order_id       INT NOT NULL,
  vendor_id      INT NOT NULL,
  sub_status     ENUM('pending','confirmed','shipped','delivered','cancelled','returned')
                 DEFAULT 'pending',
  sub_total      DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
  FOREIGN KEY (vendor_id) REFERENCES vendors(vendor_id)
) ENGINE=InnoDB;

CREATE TABLE order_items (
  order_item_id  INT AUTO_INCREMENT PRIMARY KEY,
  order_id       INT NOT NULL,
  listing_id     INT NOT NULL,
  vendor_id      INT NOT NULL,
  quantity       INT NOT NULL,
  price_at_purchase DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
  FOREIGN KEY (listing_id) REFERENCES vendor_listings(listing_id),
  FOREIGN KEY (vendor_id) REFERENCES vendors(vendor_id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 9. PAYMENTS
-- ------------------------------------------------------------
CREATE TABLE payments (
  payment_id     INT AUTO_INCREMENT PRIMARY KEY,
  order_id       INT NOT NULL,
  method         ENUM('card','upi','netbanking','cod') NOT NULL,
  amount         DECIMAL(10,2) NOT NULL,
  status         ENUM('pending','success','failed','refunded') DEFAULT 'pending',
  transaction_ref VARCHAR(100),
  paid_at        TIMESTAMP NULL,
  FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 10. REVIEWS  (structured rating; free-text + helpful-votes live in MongoDB)
-- ------------------------------------------------------------
CREATE TABLE reviews (
  review_id      INT AUTO_INCREMENT PRIMARY KEY,
  user_id        INT NOT NULL,
  listing_id     INT NOT NULL,
  rating         TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id),
  FOREIGN KEY (listing_id) REFERENCES vendor_listings(listing_id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 11. INVENTORY_ALERTS  ("Smart Inventory Alerts")
-- ------------------------------------------------------------
CREATE TABLE inventory_alerts (
  alert_id       INT AUTO_INCREMENT PRIMARY KEY,
  listing_id     INT NOT NULL,
  vendor_id      INT NOT NULL,
  alert_type     ENUM('low_stock','out_of_stock','demand_spike') NOT NULL,
  message        VARCHAR(255) NOT NULL,
  is_resolved    BOOLEAN DEFAULT FALSE,
  created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (listing_id) REFERENCES vendor_listings(listing_id) ON DELETE CASCADE,
  FOREIGN KEY (vendor_id) REFERENCES vendors(vendor_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Useful indexes for fast vendor-matching queries
-- ------------------------------------------------------------
CREATE INDEX idx_listing_product_price ON vendor_listings(product_id, price);
CREATE INDEX idx_vendor_trust ON vendors(trust_score DESC);
CREATE INDEX idx_orders_user ON orders(user_id, placed_at DESC);

-- ------------------------------------------------------------
-- Sample seed data (enough to demo Smart Vendor Matching)
-- ------------------------------------------------------------
INSERT INTO categories (name) VALUES ('Electronics'), ('Fashion'), ('Home & Kitchen');

INSERT INTO users (name, email, password_hash, role, city) VALUES
('Neha Deepika', 'neha@example.com', 'hashed_pw', 'customer', 'Hyderabad'),
('TechZone Owner', 'techzone@example.com', 'hashed_pw', 'vendor', 'Hyderabad'),
('GadgetHub Owner', 'gadgethub@example.com', 'hashed_pw', 'vendor', 'Bengaluru'),
('QuickMart Owner', 'quickmart@example.com', 'hashed_pw', 'vendor', 'Chennai');

INSERT INTO vendors (user_id, store_name, avg_delivery_days, return_rate, order_completion_rate, on_time_rate, trust_score, is_verified) VALUES
(2, 'TechZone', 2.0, 1.5, 98.0, 96.0, 91.2, TRUE),
(3, 'GadgetHub', 3.5, 4.0, 94.0, 89.0, 78.4, TRUE),
(4, 'QuickMart', 1.5, 8.0, 90.0, 85.0, 65.1, FALSE);

INSERT INTO products (category_id, name, brand, description, image_url) VALUES
(1, 'Wireless Bluetooth Earbuds', 'SoundPro', 'Noise-cancelling in-ear earbuds with 30hr battery', '/images/earbuds.png');

INSERT INTO vendor_listings (product_id, vendor_id, price, stock_qty, low_stock_threshold) VALUES
(1, 1, 1799.00, 40, 5),
(1, 2, 1649.00, 3, 5),
(1, 3, 1549.00, 12, 5);

INSERT INTO price_history (listing_id, price, recorded_at) VALUES
(1, 1999.00, DATE_SUB(NOW(), INTERVAL 30 DAY)),
(1, 1899.00, DATE_SUB(NOW(), INTERVAL 15 DAY)),
(1, 1799.00, NOW()),
(2, 1799.00, DATE_SUB(NOW(), INTERVAL 20 DAY)),
(2, 1649.00, NOW()),
(3, 1699.00, DATE_SUB(NOW(), INTERVAL 10 DAY)),
(3, 1549.00, NOW());
