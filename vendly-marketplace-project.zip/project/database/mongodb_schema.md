# MongoDB Collections — Flexible / High-Frequency Data

MySQL holds anything transactional or relational (money, stock, orders).
MongoDB holds anything **schema-flexible, high-write, or read-heavy for
personalization** — this is the "hybrid database architecture" your
abstract promises, and it's the part that actually differentiates this
project from a plain MySQL CRUD app.

Database name: `marketplace_activity`

---

## 1. `search_history`
Tracks what each customer searches for, powers recommendations.
```json
{
  "_id": "ObjectId",
  "user_id": 1,                       // FK reference to MySQL users.user_id
  "query": "wireless earbuds",
  "filters_applied": { "category": "Electronics", "max_price": 2000 },
  "searched_at": "2026-09-01T10:12:00Z"
}
```

## 2. `product_views`
Every product-detail view, used for "recently viewed" + trending detection.
```json
{
  "_id": "ObjectId",
  "user_id": 1,
  "product_id": 1,
  "listing_id": 3,
  "viewed_at": "2026-09-01T10:13:20Z",
  "session_id": "sess_88fa2"
}
```

## 3. `recommendations`
Pre-computed personalized suggestions per user (refreshed by a nightly job
or on-demand rule engine — see `backend/utils/recommendation.js`).
```json
{
  "_id": "ObjectId",
  "user_id": 1,
  "generated_at": "2026-09-10T02:00:00Z",
  "items": [
    { "product_id": 5, "score": 0.92, "reason": "Frequently bought with your last order" },
    { "product_id": 9, "score": 0.81, "reason": "Trending in Electronics near Hyderabad" }
  ]
}
```

## 4. `review_details`
Free-text review body, images, helpful-vote counters (the *rating* stays in
MySQL `reviews` for fast aggregation; the flexible content lives here).
```json
{
  "_id": "ObjectId",
  "review_id": 101,                   // FK to MySQL reviews.review_id
  "listing_id": 3,
  "title": "Great sound, fast delivery",
  "body": "...",
  "images": ["/uploads/reviews/r101_1.jpg"],
  "helpful_votes": 14,
  "vendor_reply": { "text": "Thank you!", "replied_at": "2026-09-02T09:00:00Z" }
}
```

## 5. `notifications`
Real-time alerts pushed to users/vendors (price drop, low stock, order update).
```json
{
  "_id": "ObjectId",
  "recipient_id": 2,
  "recipient_type": "vendor",
  "type": "low_stock",
  "message": "GadgetHub: Wireless Bluetooth Earbuds down to 3 units",
  "is_read": false,
  "created_at": "2026-09-10T08:00:00Z"
}
```

## 6. `vendor_activity_logs`
Append-only log of vendor actions (price changes, stock updates) — cheap to
write at high frequency, used to compute `on_time_rate` and audit trails.
```json
{
  "_id": "ObjectId",
  "vendor_id": 2,
  "action": "price_updated",
  "details": { "listing_id": 3, "old_price": 1799, "new_price": 1649 },
  "timestamp": "2026-09-08T14:22:00Z"
}
```

---

### Why this split? (say this in your viva)
| Data type | Store | Reason |
|---|---|---|
| Users, orders, payments, stock | **MySQL** | Needs ACID transactions, foreign keys, strong consistency (money & inventory must never be wrong) |
| Search/view history, recommendations, notifications, review text | **MongoDB** | High write volume, schema changes often (e.g. new recommendation reasons), read-optimized as documents, no cross-collection joins needed |

This mirrors how real marketplaces (Amazon, Flipkart) actually operate —
relational core + a document/NoSQL layer for behavioral & personalization
data.
