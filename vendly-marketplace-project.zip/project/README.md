# Vendly — Smart Multi-Vendor E-Commerce Marketplace

Full implementation matching your project abstract (Koneru Lakshmaiah
Education Foundation, 25CS1302E) — a hybrid MySQL + MongoDB backend, an
Express REST API, and a React frontend, built around five differentiating
features:

1. **Smart Vendor Matching** — ranks vendor offers by a blended score of
   price competitiveness + Vendor Trust Score, not price alone.
2. **Vendor Trust Score** — computed from on-time rate, order completion
   rate, return rate, average rating and delivery speed.
3. **Multi-Vendor Cart** — one cart, automatically grouped and checked out
   as separate per-vendor sub-orders.
4. **Price History Analysis** — tracks every price change per listing and
   tells the shopper if now is a good time to buy.
5. **Smart Inventory Alerts** — auto-generated low-stock / out-of-stock
   alerts for vendors when stock crosses a threshold.
6. **Product Recommendations** — rule-based engine combining MongoDB
   browsing signals with MySQL co-purchase data.

---

## 1. Architecture

```
React (Vite)  ──HTTP/JSON──▶  Express API  ──▶  MySQL   (users, vendors, products,
     │                            │                       orders, payments, stock)
     │                            └────────▶  MongoDB  (search history, views,
     │                                                   recommendations, notifications)
     └── axios + JWT bearer token
```

**Why two databases?** MySQL guarantees ACID transactions for money and
stock (a sale must never oversell inventory). MongoDB is used for
high-write, frequently-changing, read-optimized data — browsing history,
personalization, notifications — that doesn't need joins or strict schema.
This mirrors how real marketplaces like Amazon/Flipkart architect their
systems, and is the "hybrid database architecture" your abstract commits to.

## 2. Folder structure

```
project/
├── database/
│   ├── mysql_schema.sql       ← run this first (creates + seeds MySQL)
│   └── mongodb_schema.md      ← MongoDB collection reference (no server import needed, Mongoose creates collections on first write)
├── backend/                   ← Node.js + Express API
│   ├── config/                MySQL pool + Mongoose connection
│   ├── models/                Mongoose schemas
│   ├── controllers/           business logic (auth, products, cart, orders, vendors, recommendations)
│   ├── routes/                Express routers
│   ├── utils/                 trustScore.js (Smart Vendor Matching), recommendation.js
│   ├── middleware/auth.js     JWT auth + role guard
│   └── server.js              entry point
└── frontend/                  ← React (Vite) app
    └── src/
        ├── pages/              Home, ProductDetail, Cart, Orders, VendorDashboard, Login, Register
        ├── components/         Navbar, ProductCard, OfferRow, TrustBadge, PriceHistoryChart
        └── api/api.js          axios client with JWT interceptor
```

## 3. How to run it

**Prerequisites:** Node.js 18+, MySQL 8+, MongoDB 6+ (all installable locally or via XAMPP/MongoDB Community Server).

```bash
# 1. Create and seed the MySQL database
mysql -u root -p < database/mysql_schema.sql

# 2. Start the backend
cd backend
npm install
cp .env.example .env        # then edit DB credentials + JWT secret
npm run dev                 # runs on http://localhost:5000

# 3. Start the frontend (new terminal)
cd frontend
npm install
npm run dev                 # runs on http://localhost:5173
```

MongoDB needs no manual schema import — Mongoose creates collections
automatically the first time the app writes to them (e.g. the first
product view, the first vendor stock update).

Open **http://localhost:5173**, register a customer account and a vendor
account (use the "Account type" dropdown), and you'll be able to demo the
full flow end-to-end.

## 4. Suggested review demo script

1. **Register two vendor accounts** and list the same product at
   different prices — show the seed data already does this
   (TechZone ₹1799 / GadgetHub ₹1649 / QuickMart ₹1549 for the same
   earbuds).
2. Open the product page → point out that **QuickMart isn't ranked #1**
   despite being cheapest, because its trust score is lower — explain the
   55/45 price/trust blend in `backend/utils/trustScore.js`.
3. Add items from **two different vendors** to the cart → show the cart
   auto-groups them, and checkout creates **one order with two
   `order_vendor_split` rows** — open `orders`, `order_vendor_split`,
   `order_items` in MySQL Workbench to show the schema live.
4. On the vendor dashboard, drop stock below the threshold → show a
   **Smart Inventory Alert** appear automatically, and show the row land
   in the MongoDB `notifications` collection in MongoDB Compass.
5. Click "Recompute trust score" → show the number change live, and
   explain the weighted formula.
6. Show the **price history chart** on a product and explain how
   `isGoodDeal` is computed.

## 5. Why this is a stronger DB project than a plain CRUD store

- Real **normalization decisions**: `products` (catalog) vs
  `vendor_listings` (per-vendor price/stock) is a deliberate
  many-to-many design that is what actually enables multi-vendor
  comparison — call this out explicitly, it's usually the first thing an
  examiner probes.
- A genuine **hybrid-database justification** (not just "we used two
  databases because the abstract said so") — see the table in
  `database/mongodb_schema.md`.
- **Transactional integrity** at checkout: `orderController.js` uses a
  MySQL transaction with row locking (`FOR UPDATE`) so two customers can't
  oversell the same stock.
- Two explainable, from-scratch algorithms you can walk an examiner
  through line-by-line: `computeTrustScore()` and `rankVendorListings()`.
