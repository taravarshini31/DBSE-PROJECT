import { useEffect, useState } from 'react';
import api from '../api/api';
import ProductCard from '../components/ProductCard';

export default function Home({ user }) {
  const [products, setProducts] = useState([]);
  const [recommended, setRecommended] = useState([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    api.get('/products').then((res) => setProducts(res.data)).catch(() => {});
    if (user) {
      api.get('/recommendations').then((res) => setRecommended(res.data.recommendations)).catch(() => {});
    }
  }, [user]);

  const filtered = products.filter((p) => p.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <>
      <section className="hero">
        <div className="container">
          <h1>One search. Every vendor. The right one, ranked for you.</h1>
          <p className="lede">
            Vendly compares price, delivery speed and seller reliability across every vendor
            selling the same product — so the cheapest offer isn't always the one you see first.
          </p>
          <input
            placeholder="Search for earbuds, sarees, cookware…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{
              padding: '13px 16px', width: 360, border: '1.5px solid var(--line)',
              borderRadius: 6, fontSize: 14.5
            }}
          />
          <div className="hero-stats">
            <div className="stat"><b className="mono">{products.length}</b><span>Products live</span></div>
            <div className="stat"><b className="mono">3</b><span>Active vendors</span></div>
            <div className="stat"><b className="mono">91.2</b><span>Top trust score</span></div>
          </div>
        </div>
      </section>

      <div className="container">
        {recommended.length > 0 && (
          <>
            <div className="section-title"><h2>Picked for you</h2></div>
            <div className="product-grid">
              {recommended.map((p) => (
                <ProductCard key={`rec-${p.product_id}`} product={{ ...p, min_price: p.min_price, max_price: p.min_price, vendor_count: '' }} />
              ))}
            </div>
          </>
        )}

        <div className="section-title"><h2>All products</h2></div>
        {filtered.length ? (
          <div className="product-grid">
            {filtered.map((p) => <ProductCard key={p.product_id} product={p} />)}
          </div>
        ) : (
          <div className="empty-state">No products match your search yet.</div>
        )}
      </div>
    </>
  );
}
