import { useEffect, useState } from 'react';
import api from '../api/api';

export default function VendorDashboard() {
  const [data, setData] = useState(null);
  const [recomputing, setRecomputing] = useState(false);

  const load = () => api.get('/vendors/me/dashboard').then((res) => setData(res.data));
  useEffect(() => { load(); }, []);

  const recompute = async () => {
    setRecomputing(true);
    await api.put('/vendors/me/trust-score/recompute');
    await load();
    setRecomputing(false);
  };

  const updateStock = async (listingId, stock_qty) => {
    await api.put(`/vendors/me/listings/${listingId}`, { stock_qty });
    load();
  };

  if (!data) return <div className="container empty-state">Loading dashboard…</div>;
  const { vendor, sales, listings, alerts } = data;

  return (
    <div className="container" style={{ paddingTop: 32, paddingBottom: 60 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1 style={{ fontSize: 28 }}>{vendor.store_name}</h1>
        <button className="btn btn-outline" onClick={recompute} disabled={recomputing}>
          {recomputing ? 'Recomputing…' : 'Recompute trust score'}
        </button>
      </div>

      <div className="stat-cards">
        <div className="stat-card">
          <div className="val mono">{vendor.trust_score}</div>
          <div className="label">Trust score</div>
        </div>
        <div className="stat-card">
          <div className="val mono">{sales.total_orders}</div>
          <div className="label">Total orders</div>
        </div>
        <div className="stat-card">
          <div className="val mono">₹{Number(sales.total_revenue).toLocaleString('en-IN')}</div>
          <div className="label">Revenue</div>
        </div>
        <div className="stat-card">
          <div className="val mono">{vendor.on_time_rate}%</div>
          <div className="label">On-time delivery</div>
        </div>
      </div>

      {alerts.length > 0 && (
        <>
          <h2 style={{ fontSize: 18, marginBottom: 12 }}>Smart inventory alerts</h2>
          {alerts.map((a) => (
            <div className="alert-row" key={a.alert_id}>
              ⚠ {a.message}
            </div>
          ))}
        </>
      )}

      <h2 style={{ fontSize: 18, margin: '28px 0 12px' }}>Your listings</h2>
      {listings.map((l) => (
        <div key={l.listing_id} className="offer-row">
          <div className="store">
            <div className="store-name">Listing #{l.listing_id}</div>
            <div className="store-meta mono">₹{Number(l.price).toLocaleString('en-IN')}</div>
          </div>
          <input
            type="number"
            defaultValue={l.stock_qty}
            style={{ width: 80, padding: 8, border: '1.5px solid var(--line)', borderRadius: 4 }}
            onBlur={(e) => updateStock(l.listing_id, Number(e.target.value))}
          />
          <span style={{ fontSize: 12.5, color: '#6b7078' }}>units in stock</span>
        </div>
      ))}
    </div>
  );
}
