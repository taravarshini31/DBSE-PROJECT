import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../api/api';

export default function Register({ onLogin }) {
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'customer', city: '' });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const update = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    try {
      const res = await api.post('/auth/register', form);
      onLogin(res.data.token, res.data.user);
      navigate('/');
    } catch (e) {
      setError(e.response?.data?.error || 'Registration failed');
    }
  };

  return (
    <div className="auth-card">
      <h2 style={{ marginBottom: 6 }}>Join Vendly</h2>
      <p style={{ color: '#6b7078', fontSize: 14, marginBottom: 24 }}>As a shopper or a seller</p>
      {error && <div className="badge" style={{ background: 'var(--coral-soft)', color: 'var(--coral)', marginBottom: 14 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="field">
          <label>Full name</label>
          <input value={form.name} onChange={update('name')} required />
        </div>
        <div className="field">
          <label>Email</label>
          <input type="email" value={form.email} onChange={update('email')} required />
        </div>
        <div className="field">
          <label>Password</label>
          <input type="password" value={form.password} onChange={update('password')} required />
        </div>
        <div className="field">
          <label>City</label>
          <input value={form.city} onChange={update('city')} />
        </div>
        <div className="field">
          <label>Account type</label>
          <select value={form.role} onChange={update('role')}>
            <option value="customer">Customer</option>
            <option value="vendor">Vendor</option>
          </select>
        </div>
        <button className="btn btn-primary btn-block" type="submit">Create account</button>
      </form>
      <p style={{ fontSize: 13.5, marginTop: 18, textAlign: 'center' }}>
        Already have an account? <Link to="/login" style={{ fontWeight: 600 }}>Log in</Link>
      </p>
    </div>
  );
}
