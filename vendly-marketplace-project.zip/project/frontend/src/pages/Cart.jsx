import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api/api';

export default function Cart() {
  const [cart, setCart] = useState(null);
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const load = () => api.get('/cart').then((res) => setCart(res.data));
  useEffect(() => { load(); }, []);

  const removeItem = async (cartItemId) => {
    await api.delete(`/cart/items/${cartItemId}`);
    load();
  };

  const checkout = async () => {
    try {
      const res = await api.post('/orders/checkout');
      setMessage(`Order placed! Order #${res.data.order_id} — split across ${cart.vendors.length} vendor(s).`);
      setTimeout(() => navigate('/orders'), 1500);
    } catch (e) {
      setMessage(e.response?.data?.error || 'Checkout failed');
    }
  };

  if (!cart) return <div className="container empty-state">Loading cart…</div>;

  return (
    <div className="container" style={{ paddingTop: 32, paddingBottom: 60, maxWidth: 720 }}>
      <h1 style={{ fontSize: 28 }}>Your cart</h1>
      <p style={{ color: '#6b7078', marginBottom: 24 }}>
        Items are grouped by vendor — each group ships and is billed as a separate sub-order.
      </p>

      {message && <div className="badge badge-trust-high" style={{ marginBottom: 16 }}>{message}</div>}

      {!cart.vendors.length ? (
        <div className="empty-state">Your cart is empty. Go add something you like.</div>
      ) : (
        <>
          {cart.vendors.map((v) => (
            <div className="vendor-group" key={v.vendor_id}>
              <div className="vendor-group-header">
                <span>{v.store_name} · Trust {v.trust_score}</span>
                <span className="mono">₹{v.subtotal.toLocaleString('en-IN')}</span>
              </div>
              {v.items.map((item) => (
                <div className="cart-line" key={item.cart_item_id}>
                  <span>{item.name} × {item.quantity}</span>
                  <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
                    <span className="mono">₹{item.lineTotal.toLocaleString('en-IN')}</span>
                    <button
                      onClick={() => removeItem(item.cart_item_id)}
                      style={{ background: 'none', color: 'var(--coral)', fontSize: 13 }}
                    >
                      Remove
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ))}

          <div style={{ display: 'flex', justifyContent: 'space-between', margin: '24px 0', fontSize: 20 }}>
            <b>Grand total</b>
            <b className="mono">₹{cart.grandTotal.toLocaleString('en-IN')}</b>
          </div>

          <button className="btn btn-accent btn-block" onClick={checkout}>
            Checkout — {cart.vendors.length} vendor order{cart.vendors.length > 1 ? 's' : ''}
          </button>
        </>
      )}
    </div>
  );
}
