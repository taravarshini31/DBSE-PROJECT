import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import api from '../api/api';
import OfferRow from '../components/OfferRow';
import PriceHistoryChart from '../components/PriceHistoryChart';

export default function ProductDetail() {
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [selectedListing, setSelectedListing] = useState(null);
  const [priceData, setPriceData] = useState(null);
  const [toast, setToast] = useState('');

  useEffect(() => {
    api.get(`/products/${id}`).then((res) => {
      setData(res.data);
      if (res.data.offers?.length) setSelectedListing(res.data.offers[0].listing_id);
    });
  }, [id]);

  useEffect(() => {
    if (!selectedListing) return;
    api.get(`/products/${id}/price-history`, { params: { listing_id: selectedListing } })
      .then((res) => setPriceData(res.data));
  }, [id, selectedListing]);

  const addToCart = async (listing_id) => {
    try {
      await api.post('/cart/items', { listing_id, quantity: 1 });
      setToast('Added to cart ✓');
      setTimeout(() => setToast(''), 1800);
    } catch (e) {
      setToast(e.response?.data?.error || 'Could not add to cart');
    }
  };

  if (!data) return <div className="container empty-state">Loading product…</div>;

  return (
    <div className="container" style={{ paddingTop: 32, paddingBottom: 60 }}>
      <h1 style={{ fontSize: 30 }}>{data.product.name}</h1>
      <p style={{ color: '#6b7078', marginBottom: 30 }}>{data.product.description}</p>

      {toast && (
        <div className="badge badge-trust-high" style={{ marginBottom: 16 }}>{toast}</div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 32 }}>
        <div>
          <h2 style={{ fontSize: 18, marginBottom: 14 }}>
            {data.offers.length} vendors — ranked by Smart Vendor Matching
          </h2>
          {data.offers.map((offer, i) => (
            <div key={offer.listing_id} onClick={() => setSelectedListing(offer.listing_id)}>
              <OfferRow offer={offer} isBest={i === 0} onAddToCart={addToCart} />
            </div>
          ))}
          <p style={{ fontSize: 12.5, color: '#9aa0a8', marginTop: 8 }}>
            Ranking blends price competitiveness (55%) with vendor trust score (45%) — not price alone.
          </p>
        </div>

        <div>
          {priceData && <PriceHistoryChart history={priceData.history} insight={priceData.insight} />}
        </div>
      </div>
    </div>
  );
}
