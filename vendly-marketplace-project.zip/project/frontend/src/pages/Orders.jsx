import { useEffect, useState } from 'react';
import api from '../api/api';

export default function Orders() {
  const [orders, setOrders] = useState([]);
  useEffect(() => { api.get('/orders').then((res) => setOrders(res.data)); }, []);

  return (
    <div className="container" style={{ paddingTop: 32, paddingBottom: 60, maxWidth: 720 }}>
      <h1 style={{ fontSize: 28 }}>Your orders</h1>
      {!orders.length ? (
        <div className="empty-state">No orders yet.</div>
      ) : (
        orders.map((o) => (
          <div className="offer-row" key={o.order_id}>
            <div className="store">
              <div className="store-name">Order #{o.order_id}</div>
              <div className="store-meta">{new Date(o.placed_at).toLocaleString()}</div>
            </div>
            <span className="badge badge-trust-mid">{o.order_status}</span>
            <div className="price mono">₹{Number(o.total_amount).toLocaleString('en-IN')}</div>
          </div>
        ))
      )}
    </div>
  );
}
