import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../api/api';

export default function Login({ onLogin }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    try {
      const res = await api.post('/auth/login', { email, password });
      onLogin(res.data.token, res.data.user);
      navigate('/');
    } catch (e) {
      setError(e.response?.data?.error || 'Login failed');
    }
  };

  return (
    <div className="auth-card">
      <h2 style={{ marginBottom: 6 }}>Welcome back</h2>
      <p style={{ color: '#6b7078', fontSize: 14, marginBottom: 24 }}>Log in to Vendly</p>
      {error && <div className="badge" style={{ background: 'var(--coral-soft)', color: 'var(--coral)', marginBottom: 14 }}>{error}</div>}
      <form onSubmit={submit}>
        <div className="field">
          <label>Email</label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        <div className="field">
          <label>Password</label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        </div>
        <button className="btn btn-primary btn-block" type="submit">Log in</button>
      </form>
      <p style={{ fontSize: 13.5, marginTop: 18, textAlign: 'center' }}>
        New here? <Link to="/register" style={{ fontWeight: 600 }}>Create an account</Link>
      </p>
    </div>
  );
}
