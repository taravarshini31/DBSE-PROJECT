import { Link } from 'react-router-dom';

export default function ProductCard({ product }) {
  return (
    <Link to={`/product/${product.product_id}`} className="product-card">
      <div className="thumb">{product.brand || 'Product image'}</div>
      <div className="body">
        <h3>{product.name}</h3>
        <div className="price-row">
          <span className="price mono">₹{Number(product.min_price).toLocaleString('en-IN')}</span>
          {product.max_price > product.min_price && (
            <span className="vendor-count">
              – ₹{Number(product.max_price).toLocaleString('en-IN')}
            </span>
          )}
        </div>
        <div className="vendor-count">{product.vendor_count} vendors selling this</div>
      </div>
    </Link>
  );
}
