export default function TrustBadge({ score }) {
  let cls = 'badge-trust-low';
  let label = 'New seller';
  if (score >= 85) { cls = 'badge-trust-high'; label = `Trust ${score}`; }
  else if (score >= 65) { cls = 'badge-trust-mid'; label = `Trust ${score}`; }
  else { label = `Trust ${score}`; }

  return <span className={`badge ${cls}`}>{label}</span>;
}
