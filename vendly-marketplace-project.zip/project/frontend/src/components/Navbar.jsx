import { Link, NavLink, useNavigate } from 'react-router-dom';

export default function Navbar({ user, onLogout }) {
  const navigate = useNavigate();
  return (
    <header className="navbar">
      <div className="container">
        <Link to="/" className="brand">Vend<span>ly</span></Link>
        <nav>
          <NavLink to="/">Browse</NavLink>
          {user?.role === 'vendor' && <NavLink to="/vendor/dashboard">Dashboard</NavLink>}
          {user && <NavLink to="/orders">Orders</NavLink>}
          {user ? (
            <>
              <NavLink to="/cart" className="cart-pill">Cart</NavLink>
              <a onClick={() => { onLogout(); navigate('/login'); }}>Log out</a>
            </>
          ) : (
            <NavLink to="/login" className="cart-pill">Log in</NavLink>
          )}
        </nav>
      </div>
    </header>
  );
}
