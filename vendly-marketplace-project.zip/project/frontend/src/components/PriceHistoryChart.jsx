import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

export default function PriceHistoryChart({ history, insight }) {
  const data = history.map((h) => ({
    date: new Date(h.recorded_at).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }),
    price: Number(h.price)
  }));

  return (
    <div style={{ background: '#fff', border: '1px solid var(--line)', borderRadius: 8, padding: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
        <h3 style={{ fontFamily: 'var(--font-body)', fontSize: 15 }}>Price history</h3>
        {insight?.isGoodDeal && (
          <span className="badge badge-trust-high">Good time to buy</span>
        )}
      </div>
      <ResponsiveContainer width="100%" height={220}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e4e7e9" />
          <XAxis dataKey="date" fontSize={12} stroke="#767b83" />
          <YAxis fontSize={12} stroke="#767b83" domain={['dataMin - 100', 'dataMax + 100']} />
          <Tooltip formatter={(v) => `₹${v}`} />
          <Line type="monotone" dataKey="price" stroke="#e8a33d" strokeWidth={2.5} dot={{ r: 3 }} />
        </LineChart>
      </ResponsiveContainer>
      {insight && (
        <div style={{ display: 'flex', gap: 24, marginTop: 12, fontSize: 13, color: '#6b7078' }}>
          <span>Lowest: <b className="mono">₹{insight.lowest}</b></span>
          <span>Highest: <b className="mono">₹{insight.highest}</b></span>
          <span>Current: <b className="mono">₹{insight.current}</b></span>
        </div>
      )}
    </div>
  );
}
