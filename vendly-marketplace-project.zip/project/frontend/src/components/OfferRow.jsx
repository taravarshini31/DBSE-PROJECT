import TrustBadge from './TrustBadge';

export default function OfferRow({ offer, isBest, onAddToCart }) {
  return (
    <div className={`offer-row ${isBest ? 'best' : ''}`}>
      <div className="store">
        <div className="store-name">
          {offer.store_name}
          {offer.is_verified ? ' ✓' : ''}
        </div>
        <div className="store-meta">
          {offer.avg_delivery_days} day delivery · {offer.stock_qty} in stock
          {offer.avg_rating > 0 && <> · {Number(offer.avg_rating).toFixed(1)}★ rated</>}
        </div>
        <div style={{ marginTop: 6, display: 'flex', gap: 8 }}>
          {isBest && <span className="badge badge-best">Best match</span>}
          <TrustBadge score={offer.trust_score} />
        </div>
      </div>
      <div className="price mono">₹{Number(offer.price).toLocaleString('en-IN')}</div>
      <button className="btn btn-accent" onClick={() => onAddToCart(offer.listing_id)}>
        Add to cart
      </button>
    </div>
  );
}
